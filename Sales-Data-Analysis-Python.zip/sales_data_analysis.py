# sales_data_analysis.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv('data/sales_data_cleaned.csv')

# Aggregations
top_products = df.groupby('Product')['Quantity'].sum().sort_values(ascending=False)
monthly_sales = df.groupby(pd.to_datetime(df['Date']).dt.to_period('M'))['Revenue'].sum()
profit_region = df.groupby('Region')['Profit'].sum()
category_sales = df.groupby('Category')['Revenue'].sum()

sns.set(style='whitegrid', palette='muted', font_scale=1.1)

# Monthly sales trends
plt.figure(figsize=(10,5))
monthly_sales.plot(kind='line', marker='o')
plt.title('Monthly Sales Revenue')
plt.xlabel('Month')
plt.ylabel('Revenue')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('plots/monthly_sales_trends.png')
plt.show()

# Top-selling products
plt.figure(figsize=(8,5))
sns.barplot(x=top_products.index, y=top_products.values, palette='viridis')
plt.title('Top-selling Products by Quantity')
plt.xlabel('Product')
plt.ylabel('Quantity Sold')
plt.tight_layout()
plt.savefig('plots/top_selling_products.png')
plt.show()

# Profit per region
plt.figure(figsize=(8,5))
sns.barplot(x=profit_region.index, y=profit_region.values, palette='coolwarm')
plt.title('Profit per Region')
plt.xlabel('Region')
plt.ylabel('Profit')
plt.tight_layout()
plt.savefig('plots/profit_per_region.png')
plt.show()

# Category-wise sales distribution
plt.figure(figsize=(6,6))
plt.pie(category_sales, labels=category_sales.index, autopct='%1.1f%%', colors=['#66b3ff','#ff9999'])
plt.title('Revenue by Category')
plt.tight_layout()
plt.savefig('plots/category_sales_distribution.png')
plt.show()

print("Project Completed! Check data/ and plots/ folders for outputs.")
