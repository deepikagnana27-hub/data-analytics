
# Sales Data Analysis Project

## Overview
This project demonstrates how to turn raw sales data into actionable insights using Python, Pandas, NumPy, Matplotlib, and Seaborn.  
It simulates an e-commerce sales dataset and performs:

- Top-selling product analysis
- Monthly sales trends
- Profit per region
- Category-wise sales distribution

The project also includes visualizations and CSV outputs for further analysis.

## Tools & Skills
- Python
- Pandas, NumPy
- Matplotlib, Seaborn
- Data Cleaning & Aggregation
- Exploratory Data Analysis (EDA)
- Data Visualization

## Folder Structure
Sales-Data-Analysis-Python/
├── data/                 # Cleaned dataset CSV
├── plots/                # Graphs for insights
├── sales_data_analysis.py # Python code
└── README.md             # Project description

## How to Run
1. Clone the repository:
git clone <your-repo-url>
2. Navigate into the folder:
cd Sales-Data-Analysis-Python
3. Install required packages:
pip install pandas numpy matplotlib seaborn
4. Run the Python script:
python sales_data_analysis.py
5. Check the data/ folder for CSVs and plots/ folder for visualizations.

## Learning Outcome
This project demonstrates how structured data analysis can help businesses:

- Make data-driven decisions
- Track sales performance
- Identify high-performing products and regions
- Monitor customer behavior and trends
